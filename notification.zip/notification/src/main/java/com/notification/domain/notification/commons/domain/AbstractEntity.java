package com.notification.domain.notification.commons.domain;

public class AbstractEntity {
}
