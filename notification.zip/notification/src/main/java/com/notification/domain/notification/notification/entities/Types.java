package com.notification.domain.notification.notification.entities;
public enum Types {
    RED,GREY,LIME_GREEN,YELLOW,BLUE,DARK_GREEN
}
