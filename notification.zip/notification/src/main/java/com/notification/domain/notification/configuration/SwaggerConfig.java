package com.notification.domain.notification.configuration;
//  the stanalone spring boot app , active non-functional reqquirement like activatig the swagger console ,
// this class will fix that
public class SwaggerConfig {
}
